
#!/usr/bin/env python
print ("YODA FTW")